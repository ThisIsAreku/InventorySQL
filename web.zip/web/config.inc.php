<?php
/* configuration */
$host = 'localhost';
$user = 'root';
$pass = '1234';
$database = 'minecraft';
$table = 'InventorySQL';
?>